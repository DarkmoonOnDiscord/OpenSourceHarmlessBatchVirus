This virus is harmless !
For this to work :
put the folder "viw" on desktop
do not change any names
do not move files in the "files" folder
HAVE FUN !